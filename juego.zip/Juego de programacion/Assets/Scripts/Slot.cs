﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Slot : MonoBehaviour {
    public Database database;
    public Image itemimagen;
    public Text amountText;
    public SlotInfo slotinfo; 
     
    public void Setup (int id)
    {
        slotinfo = new SlotInfo();
        slotinfo.id = id;
        slotinfo.EmptySlot();

    }

    public void UpdateUI()
    {
        if (slotinfo.isEmpty)
        {
            itemimagen.sprite = null;
            itemimagen.enabled = false; 
        }
        else
        {
            itemimagen.sprite = database.FindItemInDatabase(slotinfo.itemid).itemimagen;
            itemimagen.enabled = true;
            if (slotinfo.amount > 1)
            {
                amountText.text = slotinfo.amount.ToString();
                amountText.gameObject.SetActive(true);
            }
            else
            {
                amountText.gameObject.SetActive(false);
            }
                
        }

    }
    [System.Serializable]
    public class SlotInfo
    {
        public int id;
        public bool isEmpty;
        public int itemid;
        public int amount;
        public int maxAmount = 10;


        public void EmptySlot()
        {
            isEmpty = true;
            amount = 0;
            itemid = -1;

        }
    }

}