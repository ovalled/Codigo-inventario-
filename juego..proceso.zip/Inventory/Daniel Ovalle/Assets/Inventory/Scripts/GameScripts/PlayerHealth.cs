﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;


public class PlayerHealth : MonoBehaviour
{
    public float currentHealth;

    public Slider healthSlider;

    public AudioClip deathClip;

	public GameObject canvas;

	private Inventory inventory;

    Animator anim;
    AudioSource playerAudio;
    PlayerMovement playerMovement;

    bool isDead;
    bool damaged;

    void Awake ()
    {
		inventory = canvas.GetComponentInChildren<Inventory> ();

        anim = GetComponent <Animator> ();
        playerAudio = GetComponent <AudioSource> ();
		playerMovement = GetComponentInChildren <PlayerMovement> ();
        //playerShooting = GetComponentInChildren <PlayerShooting> ();

    }


    void Update ()
    {
		if (Input.GetKeyDown (KeyCode.Alpha1)
		    &&
			inventory.FindItemInInventory(1).amount > 0 ) 
		{
			inventory.RemoveItem (1);

			currentHealth += 10;
		}
		if (Input.GetKeyDown (KeyCode.Alpha2)
			&&
			inventory.FindItemInInventory(2).amount > 0 ) 
		{
			inventory.RemoveItem (2);

			currentHealth += 30;
		}
    }


    public void TakeDamage (float amount)
    {
        damaged = true;

        currentHealth -= amount;

        healthSlider.value = currentHealth;

        if(currentHealth <= 0 && !isDead)
        {
            Death ();
        }
    }


    void Death ()
    {
        isDead = true;

        anim.SetTrigger ("Die");

		// playerAudio.PlayOneShot (deathClip);

        playerMovement.enabled = false;
    }


    public void RestartLevel ()
    {
        SceneManager.LoadScene (0);
    }
}
