﻿using UnityEngine;
using System.Collections;

public class EnemyAttack : MonoBehaviour
{

    public int attackDamage = 30;

    //Animator anim;
    GameObject player;

    PlayerHealth playerHealth;


    void Awake ()
    {
        player = GameObject.FindGameObjectWithTag ("Player");

        playerHealth = player.GetComponent <PlayerHealth> ();
        //enemyHealth = GetComponent<EnemyHealth>();
       // anim = GetComponent <Animator> ();
    }


    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.name == "Player")
        {
            playerHealth.TakeDamage(attackDamage);
        }
    }
}
