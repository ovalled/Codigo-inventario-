﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventario : MonoBehaviour
{

    [SerializeField]
    private Database database;

    [SerializeField]
    private GameObject slotprefab;

    [SerializeField]
    private Transform inventarioplane;


    [SerializeField]
    private List<Slotinfo> slotinfolist;

     [SerializeField]
    private int capacidad;

    private string jsonString;

    private void Start()
    {
        
        slotinfolist = new List<Slotinfo>();
        if (PlayerPrefs.HasKey("inventario"))
        {
            LoadSaveInventory();

        }
        else
        {
            // crear uno nuevo
            loadEmptyInventario();

        }

    }

    private void loadEmptyInventario()
    {
        for (int i = 0; i < capacidad; i++)
        {
            GameObject slot = Instantiate<GameObject>(slotprefab, inventarioplane);
            slot newSlot = slotprefab.GetComponent<slot>();
            newSlot.Setup(i);
            Slotinfo newSlotInfo = newSlot.slotinfo;
            slotinfolist.Add(newSlotInfo);



        }

    }
    private void LoadSaveInventory()
    {
        jsonString = PlayerPrefs.GetString("inventario");
        InvemtarioWrapper inventarioWrapper = JsonUtility.FromJson<InvemtarioWrapper>(jsonString);
        this.slotinfolist = inventarioWrapper.slotinfoList;
    }

    public Slotinfo FinditemInIventario(int itemid)
    {
        foreach (Slotinfo slotinfo in slotinfolist)
        {

            if (slotinfo.itemid == itemid && !slotinfo.isEmpty)
            {
                return slotinfo;
            }
        }
        return null;

    }
    private Slotinfo FindSuitableSlot(int itemid)

    {
        foreach (Slotinfo slotinfo in slotinfolist)
        {

            if (slotinfo.itemid == itemid && slotinfo.amount < slotinfo.maxAmount && !slotinfo.isEmpty && database.FindItemInDatabase(itemid).isStackable)
            {
                return slotinfo;
            }
        }
        foreach (Slotinfo slotinfo in slotinfolist)
        {
            if (slotinfo.isEmpty)
            {
                slotinfo.EmptySlot();
                return slotinfo;
            }

        }
        return null;
    }
    public void AddItem(int itemid)
    {
        Item item = database.FindItemInDatabase(itemid);
        if (item != null)
        {

            Slotinfo slotinfo = FindSuitableSlot(itemid);
            if (slotinfo != null)
            {
                slotinfo.amount++;
                slotinfo.itemid = itemid;
                slotinfo.isEmpty = false;

            }
        }
    }

    public void Removeitem(int itemid)
    {
        Slotinfo slotinfo = FinditemInIventario(itemid);
        if (slotinfo != null)
        {
            if (slotinfo.amount == 1)
            {
                slotinfo.EmptySlot();
            }
            else
            {
                slotinfo.amount--;
            }
        }
    }

    [ContextMenu("test Add - itempid = 1")]
    public void TestAdd()
    {
        AddItem(1);

    }
    [ContextMenu("test Remover - itempid = 1")]
    public void TestRemove()
    {

        Removeitem(1);

    }
    [ContextMenu("Test Save")]

    public void SaveInventario()
    {

        InvemtarioWrapper inventarioWrapper = new InvemtarioWrapper();
        inventarioWrapper.slotinfoList = this.slotinfolist;
        jsonString = JsonUtility.ToJson(inventarioWrapper);
        PlayerPrefs.SetString("inventario", jsonString);

    }

    private struct InvemtarioWrapper
    {

        public List<Slotinfo> slotinfoList;


    }
    

    public void TestSave()
    {

        SaveInventario();
    }


        

}
