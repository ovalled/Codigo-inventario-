﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;


public class PlayerHealth : MonoBehaviour
{
	public int startingHealth = 100; 

	public float currentHealth;

    public Slider healthSlider;

	public Image damageImage; 

    public AudioClip deathClip;

	public GameObject canvas;

	private Inventory inventory;

	public float flashSpeed = 5f; 

	public Color flashColour = new Color (1f, 0f, 0f, 0.1f);

    Animator anim;
    AudioSource playerAudio;
    PlayerMovement playerMovement;

    bool isDead;
    bool damaged;

    void Awake ()
    {
		inventory = canvas.GetComponentInChildren<Inventory> ();

        anim = GetComponent <Animator> ();
        playerAudio = GetComponent <AudioSource> ();
		playerMovement = GetComponent <PlayerMovement> ();
        //playerShooting = GetComponentInChildren <PlayerShooting> ();
		currentHealth = startingHealth; 


    }


    void Update ()
    {
		if (damaged) {

			damageImage.color = flashColour;
		} else {
			damageImage.color = Color.Lerp (damageImage.color,Color.clear,flashSpeed * Time.deltaTime);
		}
		damaged = false;

		if (Input.GetKeyDown (KeyCode.Alpha1)
		    &&
			inventory.FindItemInInventory(1).amount > 0 ) 
		{
			inventory.RemoveItem (1);

			currentHealth += 10;

			healthSlider.value = currentHealth;
		}
		if (Input.GetKeyDown (KeyCode.Alpha2)
			&&
			inventory.FindItemInInventory(2).amount > 0 ) 
		{
			inventory.RemoveItem (2);

			currentHealth += 30;

			healthSlider.value = currentHealth;
		}
    }


	public void TakeDamage (int  amount)
    {
        damaged = true;

        currentHealth -= amount;

        healthSlider.value = currentHealth;

        if(currentHealth <= 0 && !isDead)
        {
            Death ();
        }
    }


    void Death ()
    {
        isDead = true;

       anim.SetTrigger ("Die");

		// playerAudio.PlayOneShot (deathClip);

        playerMovement.enabled = false;
    }

	public void ScheduleRestarLevel()
	{
		StartCoroutine (RestartLevel ()); 

	}
	IEnumerator RestartLevel ()
    {
		yield return new WaitForSeconds (4);
		Application.LoadLevel (Application.loadedLevel); 
    }
}
