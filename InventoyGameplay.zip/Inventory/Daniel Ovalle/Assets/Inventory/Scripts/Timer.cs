﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour 
{

	public bool game;

	public Text contador ; 
	private float tiempo = 0f ;

	void Start() {

		contador.text = "" + tiempo; 

		game = true;

	}
	void Update() {

	if(game)
	{
		tiempo+=Time.deltaTime; 
		contador.text = tiempo.ToString("0"); 
	}
}
}
