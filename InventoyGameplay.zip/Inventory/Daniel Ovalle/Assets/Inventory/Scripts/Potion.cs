﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Potion : MonoBehaviour 
{
	public int id;

	public GameObject canvas;

	private Inventory inventory;

	// Use this for initialization
	void Awake () 
	{
		inventory = canvas.GetComponentInChildren<Inventory> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	private void OnCollisionEnter(Collision other)
	{

		if (other.gameObject.name == "Player")
		{
			canvas.SetActive (true);

			inventory.AddItem (id);

			canvas.SetActive (false);

			Destroy (gameObject);
		}
	}
}
