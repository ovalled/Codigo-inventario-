﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Inventario System/Datase")]
public class Database: ScriptableObject {
    public List<Item> items = new List<Item> ();
    public Item FindItemInDatabase(int id)
    {
        foreach (Item item in items) {

            if (item.id == id)
            {

                return item;
            }

        }

        return null; 
    }

	
}
[System.Serializable]
public class Item
{
    public int id;
    public string name;
    [TextArea(5,1)]
    public string descripcion;
    public Stats stats;
    public bool isStackable;
    public itemType ItemType;

    [System.Serializable]
    public struct Stats
    {
        public int damage;
        public int defense; 

    }

    public enum itemType { CONSUMABLE, WEAPON,CLOTH,QUEST,MISC}
}
